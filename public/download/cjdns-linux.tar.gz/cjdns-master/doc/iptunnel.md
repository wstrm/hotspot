IP Tunneling
============

Writing what I can, when I can. Please edit as you see fit :)

Concept
-------

An IP tunnel allows you to virtually connect one computer to another over an existing network and assign it the IP address you desire. This comes in handy when you want to connect to two different networks over one connection. In the case of cjdns, this usually means connecting to The Internet from within a cjdns network.
