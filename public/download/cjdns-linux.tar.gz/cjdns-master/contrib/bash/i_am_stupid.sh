#!/usr/bin/env bash
echo "sorry, this used to work but doesn't anymore :'(  RIP cjdroute.conf"
